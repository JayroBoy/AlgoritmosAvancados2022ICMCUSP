Arquivo zip gerado em: 14/10/2022 23:29:11 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: PD - 6