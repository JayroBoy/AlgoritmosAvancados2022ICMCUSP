Arquivo zip gerado em: 10/10/2022 13:30:28 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: PD - 3