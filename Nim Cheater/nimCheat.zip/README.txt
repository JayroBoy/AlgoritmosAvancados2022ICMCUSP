Arquivo zip gerado em: 11/12/2022 01:18:37 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: T. Jogos 1